import { Button } from "@/components/ui/button"
import { ModeToggle } from "@/components/mode-toggle"
import Link from "next/link"
import { GraduationCap, ArrowRight, Users, CreditCard } from "lucide-react"

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col">
      <header className="border-b">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold">VISHWANIKETAN&apos;S IMEET</h1>
          <div className="flex items-center gap-4">
            <ModeToggle />
            <Link href="/login">
              <Button>Login</Button>
            </Link>
          </div>
        </div>
      </header>

      <main className="flex-1">
        <section className="py-20 px-4">
          <div className="container mx-auto max-w-5xl">
            <div className="text-center mb-12">
              <h2 className="text-4xl md:text-6xl font-bold mb-6">College Accounting System</h2>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                A comprehensive solution for managing student fees, staff salaries, and financial operations.
              </p>
              <div className="mt-8 flex flex-wrap justify-center gap-4">
                <Link href="/login">
                  <Button size="lg" className="gap-2">
                    Get Started <ArrowRight className="h-4 w-4" />
                  </Button>
                </Link>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-16">
              <div className="bg-card p-6 rounded-lg shadow-sm border">
                <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                  <GraduationCap className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Student Management</h3>
                <p className="text-muted-foreground">
                  Manage student records, fee structures, and payment tracking with ease.
                </p>
              </div>

              <div className="bg-card p-6 rounded-lg shadow-sm border">
                <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                  <Users className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Staff Salary</h3>
                <p className="text-muted-foreground">
                  Track and manage staff salaries, generate payment receipts, and maintain records.
                </p>
              </div>

              <div className="bg-card p-6 rounded-lg shadow-sm border">
                <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                  <CreditCard className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Financial Dashboard</h3>
                <p className="text-muted-foreground">
                  Get insights into financial operations with comprehensive dashboards and reports.
                </p>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t py-6">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-sm text-muted-foreground">
              © {new Date().getFullYear()} VISHWANIKETAN&apos;S IMEET. All rights reserved.
            </p>
            <p className="text-sm text-muted-foreground mt-2 md:mt-0">
              Survey Nos: 52, 54, 55, 56, 57 Kumbhivali, Tal, Khalapur, Maharashtra 410203
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}
