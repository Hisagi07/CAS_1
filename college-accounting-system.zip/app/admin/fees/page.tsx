"use client"

import { useState } from "react"
import { Sidebar } from "@/components/dashboard/sidebar"
import { Header } from "@/components/dashboard/header"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Download, FileText, Plus, Printer, Search } from "lucide-react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

// Sample fee data
const feeTransactions = [
  {
    id: "TRX001",
    studentId: "STU001",
    studentName: "Rahul Sharma",
    department: "COMPUTER",
    amount: 30000,
    purpose: "Semester Fee",
    paymentMethod: "Online",
    date: "2023-04-15T09:24:45",
    status: "Completed",
  },
  {
    id: "TRX002",
    studentId: "STU002",
    studentName: "Priya Patel",
    department: "EXTC",
    amount: 25000,
    purpose: "Semester Fee",
    paymentMethod: "Online",
    date: "2023-04-14T14:10:32",
    status: "Completed",
  },
  {
    id: "TRX003",
    studentId: "STU005",
    studentName: "Suresh Joshi",
    department: "CIVIL",
    amount: 35000,
    purpose: "Semester Fee",
    paymentMethod: "Cash",
    date: "2023-04-10T10:15:22",
    status: "Completed",
  },
  {
    id: "TRX004",
    studentId: "STU004",
    studentName: "Neha Singh",
    department: "AIML",
    amount: 45000,
    purpose: "Admission Fee",
    paymentMethod: "Online",
    date: "2023-04-05T16:32:12",
    status: "Completed",
  },
  {
    id: "TRX005",
    studentId: "STU003",
    studentName: "Amit Kumar",
    department: "MECHANICAL",
    amount: 20000,
    purpose: "Exam Fee",
    paymentMethod: "Cash",
    date: "2023-04-02T11:45:00",
    status: "Pending",
  },
]

// Sample fee structures
const feeStructures = [
  {
    id: "FS001",
    department: "COMPUTER",
    year: "1st Year",
    tuitionFee: 65000,
    developmentFee: 15000,
    examFee: 5000,
    otherFees: 5000,
    totalFee: 90000,
  },
  {
    id: "FS002",
    department: "EXTC",
    year: "1st Year",
    tuitionFee: 60000,
    developmentFee: 10000,
    examFee: 5000,
    otherFees: 5000,
    totalFee: 80000,
  },
  {
    id: "FS003",
    department: "AIML",
    year: "1st Year",
    tuitionFee: 70000,
    developmentFee: 15000,
    examFee: 5000,
    otherFees: 5000,
    totalFee: 95000,
  },
  {
    id: "FS004",
    department: "MECHANICAL",
    year: "1st Year",
    tuitionFee: 55000,
    developmentFee: 15000,
    examFee: 5000,
    otherFees: 5000,
    totalFee: 80000,
  },
  {
    id: "FS005",
    department: "CIVIL",
    year: "1st Year",
    tuitionFee: 50000,
    developmentFee: 15000,
    examFee: 5000,
    otherFees: 5000,
    totalFee: 75000,
  },
]

export default function FeesPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [departmentFilter, setDepartmentFilter] = useState("all")

  // Filter transactions based on search term and filters
  const filteredTransactions = feeTransactions.filter((transaction) => {
    const matchesSearch =
      transaction.studentName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      transaction.studentId.toLowerCase().includes(searchTerm.toLowerCase()) ||
      transaction.id.toLowerCase().includes(searchTerm.toLowerCase())

    const matchesDepartment = departmentFilter === "all" || transaction.department === departmentFilter

    return matchesSearch && matchesDepartment
  })

  return (
    <div className="flex min-h-screen">
      <Sidebar />
      <div className="flex-1">
        <Header />
        <main className="p-6">
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-6 gap-4">
            <div>
              <h1 className="text-3xl font-bold tracking-tight">Fee Management</h1>
              <p className="text-muted-foreground">Manage student fees, payments, and receipts</p>
            </div>
            <div className="flex gap-2">
              <Dialog>
                <DialogTrigger asChild>
                  <Button variant="outline" className="gap-2">
                    <FileText className="h-4 w-4" />
                    Generate Receipt
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[525px]">
                  <DialogHeader>
                    <DialogTitle>Generate Fee Receipt</DialogTitle>
                    <DialogDescription>Create a new receipt for student fee payment</DialogDescription>
                  </DialogHeader>
                  <div className="grid gap-4 py-4">
                    <div className="space-y-2">
                      <Label htmlFor="student">Student</Label>
                      <Select>
                        <SelectTrigger id="student">
                          <SelectValue placeholder="Select student" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="STU001">Rahul Sharma (STU001)</SelectItem>
                          <SelectItem value="STU002">Priya Patel (STU002)</SelectItem>
                          <SelectItem value="STU003">Amit Kumar (STU003)</SelectItem>
                          <SelectItem value="STU004">Neha Singh (STU004)</SelectItem>
                          <SelectItem value="STU005">Suresh Joshi (STU005)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="purpose">Payment Purpose</Label>
                      <Select>
                        <SelectTrigger id="purpose">
                          <SelectValue placeholder="Select purpose" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="semester">Semester Fee</SelectItem>
                          <SelectItem value="admission">Admission Fee</SelectItem>
                          <SelectItem value="exam">Exam Fee</SelectItem>
                          <SelectItem value="other">Other Fee</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="amount">Amount (₹)</Label>
                      <Input id="amount" placeholder="15000" type="number" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="paymentMethod">Payment Method</Label>
                      <Select>
                        <SelectTrigger id="paymentMethod">
                          <SelectValue placeholder="Select method" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="online">Online</SelectItem>
                          <SelectItem value="cash">Cash</SelectItem>
                          <SelectItem value="cheque">Cheque</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <DialogFooter>
                    <Button type="submit">Generate Receipt</Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>

              <Dialog>
                <DialogTrigger asChild>
                  <Button className="gap-2">
                    <Plus className="h-4 w-4" />
                    Add Payment
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[525px]">
                  <DialogHeader>
                    <DialogTitle>Record Fee Payment</DialogTitle>
                    <DialogDescription>Add a new fee payment record</DialogDescription>
                  </DialogHeader>
                  <div className="grid gap-4 py-4">
                    <div className="space-y-2">
                      <Label htmlFor="student">Student</Label>
                      <Select>
                        <SelectTrigger id="student">
                          <SelectValue placeholder="Select student" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="STU001">Rahul Sharma (STU001)</SelectItem>
                          <SelectItem value="STU002">Priya Patel (STU002)</SelectItem>
                          <SelectItem value="STU003">Amit Kumar (STU003)</SelectItem>
                          <SelectItem value="STU004">Neha Singh (STU004)</SelectItem>
                          <SelectItem value="STU005">Suresh Joshi (STU005)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="purpose">Payment Purpose</Label>
                      <Select>
                        <SelectTrigger id="purpose">
                          <SelectValue placeholder="Select purpose" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="semester">Semester Fee</SelectItem>
                          <SelectItem value="admission">Admission Fee</SelectItem>
                          <SelectItem value="exam">Exam Fee</SelectItem>
                          <SelectItem value="other">Other Fee</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="amount">Amount (₹)</Label>
                      <Input id="amount" placeholder="15000" type="number" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="paymentMethod">Payment Method</Label>
                      <Select>
                        <SelectTrigger id="paymentMethod">
                          <SelectValue placeholder="Select method" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="online">Online</SelectItem>
                          <SelectItem value="cash">Cash</SelectItem>
                          <SelectItem value="cheque">Cheque</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="date">Payment Date</Label>
                      <Input id="date" type="date" />
                    </div>
                  </div>
                  <DialogFooter>
                    <Button type="submit">Add Payment</Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </div>
          </div>

          <Tabs defaultValue="transactions" className="space-y-4">
            <TabsList>
              <TabsTrigger value="transactions">Transactions</TabsTrigger>
              <TabsTrigger value="structure">Fee Structure</TabsTrigger>
              <TabsTrigger value="pending">Pending Fees</TabsTrigger>
            </TabsList>

            <TabsContent value="transactions">
              <Card>
                <CardHeader>
                  <CardTitle>Fee Transactions</CardTitle>
                  <CardDescription>View and manage all fee payments</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-col md:flex-row gap-4 mb-6">
                    <div className="relative flex-1">
                      <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                      <Input
                        placeholder="Search by student name or ID..."
                        className="pl-8"
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                      />
                    </div>
                    <Select value={departmentFilter} onValueChange={setDepartmentFilter}>
                      <SelectTrigger className="w-[180px]">
                        <SelectValue placeholder="Department" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Departments</SelectItem>
                        <SelectItem value="EXTC">EXTC</SelectItem>
                        <SelectItem value="COMPUTER">COMPUTER</SelectItem>
                        <SelectItem value="AIML">AIML</SelectItem>
                        <SelectItem value="MECHANICAL">MECHANICAL</SelectItem>
                        <SelectItem value="CIVIL">CIVIL</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="rounded-md border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Transaction ID</TableHead>
                          <TableHead>Student</TableHead>
                          <TableHead>Department</TableHead>
                          <TableHead>Purpose</TableHead>
                          <TableHead>Date</TableHead>
                          <TableHead className="text-right">Amount</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead className="text-right">Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {filteredTransactions.length === 0 ? (
                          <TableRow>
                            <TableCell colSpan={8} className="text-center h-24 text-muted-foreground">
                              No transactions found
                            </TableCell>
                          </TableRow>
                        ) : (
                          filteredTransactions.map((transaction) => (
                            <TableRow key={transaction.id}>
                              <TableCell className="font-medium">{transaction.id}</TableCell>
                              <TableCell>
                                <div>
                                  <div className="font-medium">{transaction.studentName}</div>
                                  <div className="text-sm text-muted-foreground">{transaction.studentId}</div>
                                </div>
                              </TableCell>
                              <TableCell>{transaction.department}</TableCell>
                              <TableCell>{transaction.purpose}</TableCell>
                              <TableCell>
                                {new Date(transaction.date).toLocaleDateString("en-IN", {
                                  day: "numeric",
                                  month: "short",
                                  year: "numeric",
                                })}
                              </TableCell>
                              <TableCell className="text-right">
                                ₹{transaction.amount.toLocaleString("en-IN")}
                              </TableCell>
                              <TableCell>
                                <div
                                  className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold ${
                                    transaction.status === "Completed"
                                      ? "bg-emerald-100 text-emerald-800"
                                      : "bg-amber-100 text-amber-800"
                                  }`}
                                >
                                  {transaction.status}
                                </div>
                              </TableCell>
                              <TableCell className="text-right">
                                <div className="flex justify-end gap-2">
                                  <Button variant="outline" size="icon" title="Download Receipt">
                                    <Download className="h-4 w-4" />
                                    <span className="sr-only">Download</span>
                                  </Button>
                                  <Button variant="outline" size="icon" title="Print Receipt">
                                    <Printer className="h-4 w-4" />
                                    <span className="sr-only">Print</span>
                                  </Button>
                                </div>
                              </TableCell>
                            </TableRow>
                          ))
                        )}
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="structure">
              <Card>
                <CardHeader>
                  <CardTitle>Fee Structure</CardTitle>
                  <CardDescription>View and manage fee structures for different departments</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex justify-end mb-6">
                    <Button className="gap-2">
                      <Plus className="h-4 w-4" />
                      Add Fee Structure
                    </Button>
                  </div>

                  <div className="rounded-md border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>ID</TableHead>
                          <TableHead>Department</TableHead>
                          <TableHead>Year</TableHead>
                          <TableHead className="text-right">Tuition Fee</TableHead>
                          <TableHead className="text-right">Development Fee</TableHead>
                          <TableHead className="text-right">Exam Fee</TableHead>
                          <TableHead className="text-right">Other Fees</TableHead>
                          <TableHead className="text-right">Total Fee</TableHead>
                          <TableHead className="text-right">Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {feeStructures.map((structure) => (
                          <TableRow key={structure.id}>
                            <TableCell className="font-medium">{structure.id}</TableCell>
                            <TableCell>{structure.department}</TableCell>
                            <TableCell>{structure.year}</TableCell>
                            <TableCell className="text-right">
                              ₹{structure.tuitionFee.toLocaleString("en-IN")}
                            </TableCell>
                            <TableCell className="text-right">
                              ₹{structure.developmentFee.toLocaleString("en-IN")}
                            </TableCell>
                            <TableCell className="text-right">₹{structure.examFee.toLocaleString("en-IN")}</TableCell>
                            <TableCell className="text-right">₹{structure.otherFees.toLocaleString("en-IN")}</TableCell>
                            <TableCell className="text-right font-medium">
                              ₹{structure.totalFee.toLocaleString("en-IN")}
                            </TableCell>
                            <TableCell className="text-right">
                              <Button variant="ghost" size="icon">
                                <FileText className="h-4 w-4" />
                                <span className="sr-only">Edit</span>
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="pending">
              <Card>
                <CardHeader>
                  <CardTitle>Pending Fees</CardTitle>
                  <CardDescription>View students with pending fee payments</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="rounded-md border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Student ID</TableHead>
                          <TableHead>Name</TableHead>
                          <TableHead>Department</TableHead>
                          <TableHead>Year</TableHead>
                          <TableHead className="text-right">Total Fee</TableHead>
                          <TableHead className="text-right">Paid Amount</TableHead>
                          <TableHead className="text-right">Pending Amount</TableHead>
                          <TableHead className="text-right">Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        <TableRow>
                          <TableCell className="font-medium">STU002</TableCell>
                          <TableCell>Priya Patel</TableCell>
                          <TableCell>EXTC</TableCell>
                          <TableCell>2nd Year</TableCell>
                          <TableCell className="text-right">₹75,000</TableCell>
                          <TableCell className="text-right">₹50,000</TableCell>
                          <TableCell className="text-right font-medium text-destructive">₹25,000</TableCell>
                          <TableCell className="text-right">
                            <Button variant="outline" size="sm">
                              Send Reminder
                            </Button>
                          </TableCell>
                        </TableRow>
                        <TableRow>
                          <TableCell className="font-medium">STU003</TableCell>
                          <TableCell>Amit Kumar</TableCell>
                          <TableCell>MECHANICAL</TableCell>
                          <TableCell>4th Year</TableCell>
                          <TableCell className="text-right">₹80,000</TableCell>
                          <TableCell className="text-right">₹0</TableCell>
                          <TableCell className="text-right font-medium text-destructive">₹80,000</TableCell>
                          <TableCell className="text-right">
                            <Button variant="outline" size="sm">
                              Send Reminder
                            </Button>
                          </TableCell>
                        </TableRow>
                        <TableRow>
                          <TableCell className="font-medium">STU005</TableCell>
                          <TableCell>Suresh Joshi</TableCell>
                          <TableCell>CIVIL</TableCell>
                          <TableCell>3rd Year</TableCell>
                          <TableCell className="text-right">₹70,000</TableCell>
                          <TableCell className="text-right">₹35,000</TableCell>
                          <TableCell className="text-right font-medium text-destructive">₹35,000</TableCell>
                          <TableCell className="text-right">
                            <Button variant="outline" size="sm">
                              Send Reminder
                            </Button>
                          </TableCell>
                        </TableRow>
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </main>
      </div>
    </div>
  )
}
