"use client"

import { useState } from "react"
import { Sidebar } from "@/components/dashboard/sidebar"
import { Header } from "@/components/dashboard/header"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { FileText, Plus, Printer, Search } from "lucide-react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { SalaryReceiptGenerator } from "@/components/salary-receipt-generator"

// Sample salary data
const salaryTransactions = [
  {
    id: "SAL001",
    staffId: "STAFF001",
    staffName: "Dr. Rajesh Verma",
    department: "COMPUTER",
    amount: 85000,
    month: "April 2023",
    paymentMethod: "Bank Transfer",
    date: "2023-04-28T09:24:45",
    status: "Completed",
  },
  {
    id: "SAL002",
    staffId: "STAFF002",
    staffName: "Dr. Priya Sharma",
    department: "EXTC",
    amount: 75000,
    month: "April 2023",
    paymentMethod: "Bank Transfer",
    date: "2023-04-28T14:10:32",
    status: "Completed",
  },
  {
    id: "SAL003",
    staffId: "STAFF003",
    staffName: "Prof. Amit Patel",
    department: "MECHANICAL",
    amount: 65000,
    month: "April 2023",
    paymentMethod: "Bank Transfer",
    date: "2023-04-28T10:15:22",
    status: "Completed",
  },
  {
    id: "SAL004",
    staffId: "STAFF004",
    staffName: "Dr. Neha Singh",
    department: "AIML",
    amount: 90000,
    month: "April 2023",
    paymentMethod: "Bank Transfer",
    date: "2023-04-28T16:32:12",
    status: "Completed",
  },
  {
    id: "SAL005",
    staffId: "STAFF005",
    staffName: "Prof. Suresh Kumar",
    department: "CIVIL",
    amount: 60000,
    month: "April 2023",
    paymentMethod: "Bank Transfer",
    date: "2023-04-28T11:45:00",
    status: "Pending",
  },
]

export default function SalariesPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [departmentFilter, setDepartmentFilter] = useState("all")
  const [selectedSalary, setSelectedSalary] = useState<(typeof salaryTransactions)[0] | null>(null)
  const [showReceipt, setShowReceipt] = useState(false)

  // Filter transactions based on search term and filters
  const filteredTransactions = salaryTransactions.filter((transaction) => {
    const matchesSearch =
      transaction.staffName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      transaction.staffId.toLowerCase().includes(searchTerm.toLowerCase()) ||
      transaction.id.toLowerCase().includes(searchTerm.toLowerCase())

    const matchesDepartment = departmentFilter === "all" || transaction.department === departmentFilter

    return matchesSearch && matchesDepartment
  })

  const handleGenerateReceipt = (salary: (typeof salaryTransactions)[0]) => {
    setSelectedSalary(salary)
    setShowReceipt(true)
  }

  return (
    <div className="flex min-h-screen">
      <Sidebar />
      <div className="flex-1">
        <Header />
        <main className="p-6">
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-6 gap-4">
            <div>
              <h1 className="text-3xl font-bold tracking-tight">Salary Management</h1>
              <p className="text-muted-foreground">Manage staff salaries, payments, and receipts</p>
            </div>
            <div className="flex gap-2">
              <Dialog>
                <DialogTrigger asChild>
                  <Button variant="outline" className="gap-2">
                    <FileText className="h-4 w-4" />
                    Generate Salary Slip
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[525px]">
                  <DialogHeader>
                    <DialogTitle>Generate Salary Slip</DialogTitle>
                    <DialogDescription>Create a new salary slip for staff member</DialogDescription>
                  </DialogHeader>
                  <div className="grid gap-4 py-4">
                    <div className="space-y-2">
                      <Label htmlFor="staff">Staff Member</Label>
                      <Select>
                        <SelectTrigger id="staff">
                          <SelectValue placeholder="Select staff member" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="STAFF001">Dr. Rajesh Verma (STAFF001)</SelectItem>
                          <SelectItem value="STAFF002">Dr. Priya Sharma (STAFF002)</SelectItem>
                          <SelectItem value="STAFF003">Prof. Amit Patel (STAFF003)</SelectItem>
                          <SelectItem value="STAFF004">Dr. Neha Singh (STAFF004)</SelectItem>
                          <SelectItem value="STAFF005">Prof. Suresh Kumar (STAFF005)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="month">Month</Label>
                      <Select>
                        <SelectTrigger id="month">
                          <SelectValue placeholder="Select month" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="april2023">April 2023</SelectItem>
                          <SelectItem value="march2023">March 2023</SelectItem>
                          <SelectItem value="february2023">February 2023</SelectItem>
                          <SelectItem value="january2023">January 2023</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="basicSalary">Basic Salary (₹)</Label>
                      <Input id="basicSalary" placeholder="60000" type="number" />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="allowances">Allowances (₹)</Label>
                        <Input id="allowances" placeholder="15000" type="number" />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="deductions">Deductions (₹)</Label>
                        <Input id="deductions" placeholder="5000" type="number" />
                      </div>
                    </div>
                  </div>
                  <DialogFooter>
                    <Button type="submit">Generate Slip</Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>

              <Dialog>
                <DialogTrigger asChild>
                  <Button className="gap-2">
                    <Plus className="h-4 w-4" />
                    Process Salary
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[525px]">
                  <DialogHeader>
                    <DialogTitle>Process Salary Payment</DialogTitle>
                    <DialogDescription>Add a new salary payment record</DialogDescription>
                  </DialogHeader>
                  <div className="grid gap-4 py-4">
                    <div className="space-y-2">
                      <Label htmlFor="staff">Staff Member</Label>
                      <Select>
                        <SelectTrigger id="staff">
                          <SelectValue placeholder="Select staff member" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="STAFF001">Dr. Rajesh Verma (STAFF001)</SelectItem>
                          <SelectItem value="STAFF002">Dr. Priya Sharma (STAFF002)</SelectItem>
                          <SelectItem value="STAFF003">Prof. Amit Patel (STAFF003)</SelectItem>
                          <SelectItem value="STAFF004">Dr. Neha Singh (STAFF004)</SelectItem>
                          <SelectItem value="STAFF005">Prof. Suresh Kumar (STAFF005)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="month">Month</Label>
                      <Select>
                        <SelectTrigger id="month">
                          <SelectValue placeholder="Select month" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="april2023">April 2023</SelectItem>
                          <SelectItem value="march2023">March 2023</SelectItem>
                          <SelectItem value="february2023">February 2023</SelectItem>
                          <SelectItem value="january2023">January 2023</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="amount">Total Amount (₹)</Label>
                      <Input id="amount" placeholder="75000" type="number" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="paymentMethod">Payment Method</Label>
                      <Select>
                        <SelectTrigger id="paymentMethod">
                          <SelectValue placeholder="Select method" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="bank">Bank Transfer</SelectItem>
                          <SelectItem value="cash">Cash</SelectItem>
                          <SelectItem value="cheque">Cheque</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="date">Payment Date</Label>
                      <Input id="date" type="date" />
                    </div>
                  </div>
                  <DialogFooter>
                    <Button type="submit">Process Payment</Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </div>
          </div>

          {showReceipt && selectedSalary ? (
            <div className="mb-6">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between">
                  <div>
                    <CardTitle>Salary Slip</CardTitle>
                    <CardDescription>Salary slip for {selectedSalary.staffName}</CardDescription>
                  </div>
                  <Button variant="outline" onClick={() => setShowReceipt(false)}>
                    Back to List
                  </Button>
                </CardHeader>
                <CardContent>
                  <SalaryReceiptGenerator
                    salaryData={{
                      receiptNo: selectedSalary.id,
                      date: new Date(selectedSalary.date).toLocaleDateString("en-IN"),
                      staffName: selectedSalary.staffName,
                      staffId: selectedSalary.staffId,
                      department: selectedSalary.department,
                      month: selectedSalary.month,
                      basicSalary: Math.round(selectedSalary.amount * 0.7),
                      allowances: Math.round(selectedSalary.amount * 0.3),
                      deductions: Math.round(selectedSalary.amount * 0.1),
                      netSalary: selectedSalary.amount,
                      paymentMethod: selectedSalary.paymentMethod,
                    }}
                  />
                </CardContent>
              </Card>
            </div>
          ) : (
            <Tabs defaultValue="transactions" className="space-y-4">
              <TabsList>
                <TabsTrigger value="transactions">Transactions</TabsTrigger>
                <TabsTrigger value="structure">Salary Structure</TabsTrigger>
                <TabsTrigger value="pending">Pending Salaries</TabsTrigger>
              </TabsList>

              <TabsContent value="transactions">
                <Card>
                  <CardHeader>
                    <CardTitle>Salary Transactions</CardTitle>
                    <CardDescription>View and manage all salary payments</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex flex-col md:flex-row gap-4 mb-6">
                      <div className="relative flex-1">
                        <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                        <Input
                          placeholder="Search by staff name or ID..."
                          className="pl-8"
                          value={searchTerm}
                          onChange={(e) => setSearchTerm(e.target.value)}
                        />
                      </div>
                      <Select value={departmentFilter} onValueChange={setDepartmentFilter}>
                        <SelectTrigger className="w-[180px]">
                          <SelectValue placeholder="Department" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">All Departments</SelectItem>
                          <SelectItem value="EXTC">EXTC</SelectItem>
                          <SelectItem value="COMPUTER">COMPUTER</SelectItem>
                          <SelectItem value="AIML">AIML</SelectItem>
                          <SelectItem value="MECHANICAL">MECHANICAL</SelectItem>
                          <SelectItem value="CIVIL">CIVIL</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="rounded-md border">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Transaction ID</TableHead>
                            <TableHead>Staff</TableHead>
                            <TableHead>Department</TableHead>
                            <TableHead>Month</TableHead>
                            <TableHead>Date</TableHead>
                            <TableHead className="text-right">Amount</TableHead>
                            <TableHead>Status</TableHead>
                            <TableHead className="text-right">Actions</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {filteredTransactions.length === 0 ? (
                            <TableRow>
                              <TableCell colSpan={8} className="text-center h-24 text-muted-foreground">
                                No transactions found
                              </TableCell>
                            </TableRow>
                          ) : (
                            filteredTransactions.map((transaction) => (
                              <TableRow key={transaction.id}>
                                <TableCell className="font-medium">{transaction.id}</TableCell>
                                <TableCell>
                                  <div>
                                    <div className="font-medium">{transaction.staffName}</div>
                                    <div className="text-sm text-muted-foreground">{transaction.staffId}</div>
                                  </div>
                                </TableCell>
                                <TableCell>{transaction.department}</TableCell>
                                <TableCell>{transaction.month}</TableCell>
                                <TableCell>
                                  {new Date(transaction.date).toLocaleDateString("en-IN", {
                                    day: "numeric",
                                    month: "short",
                                    year: "numeric",
                                  })}
                                </TableCell>
                                <TableCell className="text-right">
                                  ₹{transaction.amount.toLocaleString("en-IN")}
                                </TableCell>
                                <TableCell>
                                  <div
                                    className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold ${
                                      transaction.status === "Completed"
                                        ? "bg-emerald-100 text-emerald-800"
                                        : "bg-amber-100 text-amber-800"
                                    }`}
                                  >
                                    {transaction.status}
                                  </div>
                                </TableCell>
                                <TableCell className="text-right">
                                  <div className="flex justify-end gap-2">
                                    <Button
                                      variant="outline"
                                      size="icon"
                                      title="Generate Salary Slip"
                                      onClick={() => handleGenerateReceipt(transaction)}
                                    >
                                      <FileText className="h-4 w-4" />
                                      <span className="sr-only">Generate</span>
                                    </Button>
                                    <Button variant="outline" size="icon" title="Print Salary Slip">
                                      <Printer className="h-4 w-4" />
                                      <span className="sr-only">Print</span>
                                    </Button>
                                  </div>
                                </TableCell>
                              </TableRow>
                            ))
                          )}
                        </TableBody>
                      </Table>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="structure">
                <Card>
                  <CardHeader>
                    <CardTitle>Salary Structure</CardTitle>
                    <CardDescription>View and manage salary structures for different positions</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex justify-end mb-6">
                      <Button className="gap-2">
                        <Plus className="h-4 w-4" />
                        Add Salary Structure
                      </Button>
                    </div>

                    <div className="rounded-md border">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Position</TableHead>
                            <TableHead>Department</TableHead>
                            <TableHead className="text-right">Basic Salary</TableHead>
                            <TableHead className="text-right">HRA</TableHead>
                            <TableHead className="text-right">DA</TableHead>
                            <TableHead className="text-right">Other Allowances</TableHead>
                            <TableHead className="text-right">Total</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          <TableRow>
                            <TableCell className="font-medium">Professor</TableCell>
                            <TableCell>All</TableCell>
                            <TableCell className="text-right">₹60,000</TableCell>
                            <TableCell className="text-right">₹15,000</TableCell>
                            <TableCell className="text-right">₹8,000</TableCell>
                            <TableCell className="text-right">₹7,000</TableCell>
                            <TableCell className="text-right font-medium">₹90,000</TableCell>
                          </TableRow>
                          <TableRow>
                            <TableCell className="font-medium">Associate Professor</TableCell>
                            <TableCell>All</TableCell>
                            <TableCell className="text-right">₹50,000</TableCell>
                            <TableCell className="text-right">₹12,500</TableCell>
                            <TableCell className="text-right">₹7,000</TableCell>
                            <TableCell className="text-right">₹5,500</TableCell>
                            <TableCell className="text-right font-medium">₹75,000</TableCell>
                          </TableRow>
                          <TableRow>
                            <TableCell className="font-medium">Assistant Professor</TableCell>
                            <TableCell>All</TableCell>
                            <TableCell className="text-right">₹40,000</TableCell>
                            <TableCell className="text-right">₹10,000</TableCell>
                            <TableCell className="text-right">₹6,000</TableCell>
                            <TableCell className="text-right">₹4,000</TableCell>
                            <TableCell className="text-right font-medium">₹60,000</TableCell>
                          </TableRow>
                          <TableRow>
                            <TableCell className="font-medium">Lecturer</TableCell>
                            <TableCell>All</TableCell>
                            <TableCell className="text-right">₹35,000</TableCell>
                            <TableCell className="text-right">₹8,750</TableCell>
                            <TableCell className="text-right">₹5,250</TableCell>
                            <TableCell className="text-right">₹3,500</TableCell>
                            <TableCell className="text-right font-medium">₹52,500</TableCell>
                          </TableRow>
                        </TableBody>
                      </Table>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="pending">
                <Card>
                  <CardHeader>
                    <CardTitle>Pending Salaries</CardTitle>
                    <CardDescription>View staff with pending salary payments</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="rounded-md border">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Staff ID</TableHead>
                            <TableHead>Name</TableHead>
                            <TableHead>Department</TableHead>
                            <TableHead>Position</TableHead>
                            <TableHead>Month</TableHead>
                            <TableHead className="text-right">Amount</TableHead>
                            <TableHead className="text-right">Actions</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          <TableRow>
                            <TableCell className="font-medium">STAFF005</TableCell>
                            <TableCell>Prof. Suresh Kumar</TableCell>
                            <TableCell>CIVIL</TableCell>
                            <TableCell>Assistant Professor</TableCell>
                            <TableCell>April 2023</TableCell>
                            <TableCell className="text-right">₹60,000</TableCell>
                            <TableCell className="text-right">
                              <Button variant="outline" size="sm">
                                Process Now
                              </Button>
                            </TableCell>
                          </TableRow>
                        </TableBody>
                      </Table>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          )}
        </main>
      </div>
    </div>
  )
}
