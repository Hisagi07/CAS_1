"use client"

import { Sidebar } from "@/components/dashboard/sidebar"
import { Header } from "@/components/dashboard/header"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { useAuth } from "@/components/auth-provider"
import { ArrowRight, Bell, Calendar, Download, FileText, IndianRupee } from "lucide-react"
import Link from "next/link"

export default function StudentDashboard() {
  const { user } = useAuth()

  return (
    <div className="flex min-h-screen">
      <Sidebar />
      <div className="flex-1">
        <Header />
        <main className="p-6">
          <div className="mb-6">
            <h1 className="text-3xl font-bold tracking-tight">Welcome, {user?.name}</h1>
            <p className="text-muted-foreground">Here's an overview of your academic finances</p>
          </div>

          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3 mb-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Current Semester Fee</CardTitle>
                <IndianRupee className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">₹45,000</div>
                <div className="mt-4 space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Paid</span>
                    <span>₹30,000 (67%)</span>
                  </div>
                  <Progress value={67} className="h-2" />
                </div>
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="w-full" asChild>
                  <Link href="/student/fees">View Details</Link>
                </Button>
              </CardFooter>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Payment Due</CardTitle>
                <Calendar className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">₹15,000</div>
                <p className="text-xs text-muted-foreground mt-1">Due by: 30 April, 2023</p>
                <Alert variant="destructive" className="mt-4">
                  <Bell className="h-4 w-4" />
                  <AlertTitle>Payment Reminder</AlertTitle>
                  <AlertDescription>Your next installment is due in 15 days.</AlertDescription>
                </Alert>
              </CardContent>
              <CardFooter>
                <Button className="w-full">Pay Now</Button>
              </CardFooter>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Recent Receipt</CardTitle>
                <FileText className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">₹15,000</div>
                <div className="flex justify-between mt-1">
                  <p className="text-xs text-muted-foreground">Transaction ID: VN78945612</p>
                  <p className="text-xs text-muted-foreground">15 Mar, 2023</p>
                </div>
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="w-full gap-2">
                  <Download className="h-4 w-4" /> Download Receipt
                </Button>
              </CardFooter>
            </Card>
          </div>

          <Tabs defaultValue="transactions" className="space-y-4">
            <TabsList>
              <TabsTrigger value="transactions">Transactions</TabsTrigger>
              <TabsTrigger value="documents">Documents</TabsTrigger>
              <TabsTrigger value="announcements">Announcements</TabsTrigger>
            </TabsList>

            <TabsContent value="transactions" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Recent Transactions</CardTitle>
                  <CardDescription>Your recent fee payments and transactions</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    {[1, 2, 3].map((i) => (
                      <div key={i} className="flex items-center justify-between border-b pb-4 last:border-0 last:pb-0">
                        <div className="space-y-1">
                          <p className="text-sm font-medium">Semester Fee Payment</p>
                          <p className="text-xs text-muted-foreground">
                            {i === 1 ? "15 Mar, 2023" : i === 2 ? "15 Feb, 2023" : "15 Jan, 2023"}
                          </p>
                        </div>
                        <div className="flex items-center gap-4">
                          <span className="text-sm font-medium">₹15,000</span>
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <Download className="h-4 w-4" />
                            <span className="sr-only">Download</span>
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
                <CardFooter>
                  <Button variant="outline" className="w-full" asChild>
                    <Link href="/student/payments">
                      View All Transactions <ArrowRight className="ml-2 h-4 w-4" />
                    </Link>
                  </Button>
                </CardFooter>
              </Card>
            </TabsContent>

            <TabsContent value="documents" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Important Documents</CardTitle>
                  <CardDescription>Access and download your academic documents</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {["Fee Structure", "Admission Letter", "ID Card"].map((doc) => (
                      <div
                        key={doc}
                        className="flex items-center justify-between border-b pb-4 last:border-0 last:pb-0"
                      >
                        <div className="flex items-center gap-3">
                          <FileText className="h-5 w-5 text-muted-foreground" />
                          <span className="text-sm font-medium">{doc}</span>
                        </div>
                        <Button variant="outline" size="sm" className="gap-2">
                          <Download className="h-4 w-4" /> Download
                        </Button>
                      </div>
                    ))}
                  </div>
                </CardContent>
                <CardFooter>
                  <Button variant="outline" className="w-full" asChild>
                    <Link href="/student/documents">
                      View All Documents <ArrowRight className="ml-2 h-4 w-4" />
                    </Link>
                  </Button>
                </CardFooter>
              </Card>
            </TabsContent>

            <TabsContent value="announcements" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Announcements</CardTitle>
                  <CardDescription>Important notices and announcements</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    {[
                      {
                        title: "Fee Payment Deadline Extended",
                        date: "10 Apr, 2023",
                        content: "The deadline for semester fee payment has been extended to April 30, 2023.",
                      },
                      {
                        title: "New Online Payment System",
                        date: "5 Apr, 2023",
                        content:
                          "We have upgraded our payment system. Now you can pay your fees using UPI, Net Banking, and Credit/Debit cards.",
                      },
                      {
                        title: "Scholarship Applications Open",
                        date: "1 Apr, 2023",
                        content:
                          "Applications for merit scholarships are now open. Last date to apply is April 20, 2023.",
                      },
                    ].map((announcement, i) => (
                      <div key={i} className="border-b pb-4 last:border-0 last:pb-0">
                        <div className="flex justify-between mb-2">
                          <h4 className="text-sm font-medium">{announcement.title}</h4>
                          <span className="text-xs text-muted-foreground">{announcement.date}</span>
                        </div>
                        <p className="text-sm text-muted-foreground">{announcement.content}</p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </main>
      </div>
    </div>
  )
}
