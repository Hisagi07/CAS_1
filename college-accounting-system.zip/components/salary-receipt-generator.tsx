"\"use client"

import { useRef } from "react"
import { Button } from "@/components/ui/button"
import { Download, Printer } from "lucide-react"
import { useReactToPrint } from "react-to-print"

interface SalaryReceiptGeneratorProps {
  salaryData: {
    receiptNo: string
    date: string
    staffName: string
    staffId: string
    department: string
    month: string
    basicSalary: number
    allowances: number
    deductions: number
    netSalary: number
    paymentMethod: string
  }
}

export function SalaryReceiptGenerator({ salaryData }: SalaryReceiptGeneratorProps) {
  const receiptRef = useRef<HTMLDivElement>(null)

  const handlePrint = useReactToPrint({
    content: () => receiptRef.current,
  })

  return (
    <div className="space-y-4">
      <div className="flex justify-end gap-2">
        <Button variant="outline" className="gap-2" onClick={handlePrint}>
          <Printer className="h-4 w-4" />
          Print Receipt
        </Button>
        <Button className="gap-2">
          <Download className="h-4 w-4" />
          Download PDF
        </Button>
      </div>

      <div
        ref={receiptRef}
        className="border rounded-md p-8 bg-white text-black"
        style={{ width: "210mm", minHeight: "148mm" }}
      >
        <div className="text-center mb-6">
          <h1 className="text-2xl font-bold uppercase">VISHWANIKETAN&apos;S IMEET</h1>
          <p className="text-sm">Survey Nos: 52, 54, 55, 56, 57 Kumbhivali, Tal, Khalapur, Maharashtra 410203</p>
          <div className="mt-2 text-lg font-semibold">SALARY RECEIPT</div>
        </div>

        <div className="flex justify-between mb-6">
          <div>
            <p>
              <span className="font-semibold">Receipt No:</span> {salaryData.receiptNo}
            </p>
            <p>
              <span className="font-semibold">Staff ID:</span> {salaryData.staffId}
            </p>
            <p>
              <span className="font-semibold">Department:</span> {salaryData.department}
            </p>
          </div>
          <div>
            <p>
              <span className="font-semibold">Date:</span> {salaryData.date}
            </p>
            <p>
              <span className="font-semibold">Payment Method:</span> {salaryData.paymentMethod}
            </p>
          </div>
        </div>

        <div className="mb-6">
          <p>
            <span className="font-semibold">Staff Name:</span> {salaryData.staffName}
          </p>
          <p>
            <span className="font-semibold">Month:</span> {salaryData.month}
          </p>
        </div>

        <div className="border-t border-b py-4 mb-6">
          <div className="flex justify-between font-semibold">
            <span>Description</span>
            <span>Amount</span>
          </div>
          <div className="flex justify-between mt-2">
            <span>Basic Salary</span>
            <span>₹{salaryData.basicSalary.toLocaleString("en-IN")}</span>
          </div>
          <div className="flex justify-between mt-2">
            <span>Allowances</span>
            <span>₹{salaryData.allowances.toLocaleString("en-IN")}</span>
          </div>
          <div className="flex justify-between mt-2">
            <span>Deductions</span>
            <span>₹{salaryData.deductions.toLocaleString("en-IN")}</span>
          </div>
          <div className="flex justify-between mt-4 font-bold">
            <span>Net Salary</span>
            <span>₹{salaryData.netSalary.toLocaleString("en-IN")}</span>
          </div>
        </div>

        <div className="flex justify-between">
          <div>
            <p className="font-semibold">Received with thanks,</p>
            <div className="mt-8 pt-2 border-t w-40">
              <p className="text-center text-sm">Authorized Signature</p>
            </div>
          </div>
          <div className="text-center">
            <div className="mt-8 pt-2 border-t w-40">
              <p className="text-center text-sm">Staff Signature</p>
            </div>
          </div>
        </div>

        <div className="mt-8 text-center text-xs text-gray-500">
          <p>This is a computer-generated receipt and does not require a physical signature.</p>
          <p>For any queries, please contact the accounts department.</p>
        </div>
      </div>
    </div>
  )
}
