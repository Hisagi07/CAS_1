"use client"

import type React from "react"

import { createContext, useContext, useState, useEffect } from "react"
import { useRouter, usePathname } from "next/navigation"

type User = {
  id: string
  name: string
  email: string
  role: "admin" | "student"
  department?: "EXTC" | "COMPUTER" | "AIML" | "MECHANICAL" | "CIVIL"
}

type AuthContextType = {
  user: User | null
  login: (email: string, password: string) => Promise<void>
  logout: () => void
  loading: boolean
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)
  const router = useRouter()
  const pathname = usePathname()

  // Check if user is logged in on mount
  useEffect(() => {
    const storedUser = localStorage.getItem("user")
    if (storedUser) {
      setUser(JSON.parse(storedUser))
    }
    setLoading(false)
  }, [])

  // Protect routes
  useEffect(() => {
    if (!loading) {
      // Public routes
      const publicRoutes = ["/", "/login", "/signup"]

      // If not logged in and trying to access protected route
      if (!user && !publicRoutes.includes(pathname)) {
        router.push("/login")
      }

      // If logged in and trying to access login/signup
      if (user && (pathname === "/login" || pathname === "/signup")) {
        router.push(user.role === "admin" ? "/admin/dashboard" : "/student/dashboard")
      }
    }
  }, [user, loading, pathname, router])

  const login = async (email: string, password: string) => {
    setLoading(true)
    try {
      // In a real app, this would be an API call
      // For demo purposes, we'll use dummy data

      // Admin login
      if (email === "admin@vishwaniketan.edu" && password === "admin123") {
        const adminUser: User = {
          id: "admin-1",
          name: "Admin User",
          email: "admin@vishwaniketan.edu",
          role: "admin",
        }
        setUser(adminUser)
        localStorage.setItem("user", JSON.stringify(adminUser))
        router.push("/admin/dashboard")
        return
      }

      // Student login
      if (email === "student@vishwaniketan.edu" && password === "student123") {
        const studentUser: User = {
          id: "student-1",
          name: "Student User",
          email: "student@vishwaniketan.edu",
          role: "student",
          department: "COMPUTER",
        }
        setUser(studentUser)
        localStorage.setItem("user", JSON.stringify(studentUser))
        router.push("/student/dashboard")
        return
      }

      throw new Error("Invalid credentials")
    } catch (error) {
      console.error("Login failed:", error)
      throw error
    } finally {
      setLoading(false)
    }
  }

  const logout = () => {
    setUser(null)
    localStorage.removeItem("user")
    router.push("/login")
  }

  return <AuthContext.Provider value={{ user, login, logout, loading }}>{children}</AuthContext.Provider>
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
