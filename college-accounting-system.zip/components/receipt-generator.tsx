"use client"

import { useRef } from "react"
import { Button } from "@/components/ui/button"
import { Download, Printer } from "lucide-react"
import { useReactToPrint } from "react-to-print"

interface ReceiptGeneratorProps {
  receiptData: {
    receiptNo: string
    date: string
    studentName: string
    studentId: string
    department: string
    purpose: string
    amount: number
    paymentMethod: string
  }
}

export function ReceiptGenerator({ receiptData }: ReceiptGeneratorProps) {
  const receiptRef = useRef<HTMLDivElement>(null)

  const handlePrint = useReactToPrint({
    content: () => receiptRef.current,
  })

  return (
    <div className="space-y-4">
      <div className="flex justify-end gap-2">
        <Button variant="outline" className="gap-2" onClick={handlePrint}>
          <Printer className="h-4 w-4" />
          Print Receipt
        </Button>
        <Button className="gap-2">
          <Download className="h-4 w-4" />
          Download PDF
        </Button>
      </div>

      <div
        ref={receiptRef}
        className="border rounded-md p-8 bg-white text-black"
        style={{ width: "210mm", minHeight: "148mm" }}
      >
        <div className="text-center mb-6">
          <h1 className="text-2xl font-bold uppercase">VISHWANIKETAN&apos;S IMEET</h1>
          <p className="text-sm">Survey Nos: 52, 54, 55, 56, 57 Kumbhivali, Tal, Khalapur, Maharashtra 410203</p>
          <div className="mt-2 text-lg font-semibold">PAYMENT RECEIPT</div>
        </div>

        <div className="flex justify-between mb-6">
          <div>
            <p>
              <span className="font-semibold">Receipt No:</span> {receiptData.receiptNo}
            </p>
            <p>
              <span className="font-semibold">Student ID:</span> {receiptData.studentId}
            </p>
            <p>
              <span className="font-semibold">Department:</span> {receiptData.department}
            </p>
          </div>
          <div>
            <p>
              <span className="font-semibold">Date:</span> {receiptData.date}
            </p>
            <p>
              <span className="font-semibold">Payment Method:</span> {receiptData.paymentMethod}
            </p>
          </div>
        </div>

        <div className="mb-6">
          <p>
            <span className="font-semibold">Student Name:</span> {receiptData.studentName}
          </p>
          <p>
            <span className="font-semibold">Purpose:</span> {receiptData.purpose}
          </p>
        </div>

        <div className="border-t border-b py-4 mb-6">
          <div className="flex justify-between font-semibold">
            <span>Description</span>
            <span>Amount</span>
          </div>
          <div className="flex justify-between mt-2">
            <span>{receiptData.purpose}</span>
            <span>₹{receiptData.amount.toLocaleString("en-IN")}</span>
          </div>
          <div className="flex justify-between mt-4 font-bold">
            <span>Total</span>
            <span>₹{receiptData.amount.toLocaleString("en-IN")}</span>
          </div>
        </div>

        <div className="flex justify-between">
          <div>
            <p className="font-semibold">Received with thanks,</p>
            <div className="mt-8 pt-2 border-t w-40">
              <p className="text-center text-sm">Authorized Signature</p>
            </div>
          </div>
          <div className="text-center">
            <div className="mt-8 pt-2 border-t w-40">
              <p className="text-center text-sm">Student Signature</p>
            </div>
          </div>
        </div>

        <div className="mt-8 text-center text-xs text-gray-500">
          <p>This is a computer-generated receipt and does not require a physical signature.</p>
          <p>For any queries, please contact the accounts department.</p>
        </div>
      </div>
    </div>
  )
}
