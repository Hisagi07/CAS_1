"use client"

import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { ArrowDownLeft, ArrowUpRight, CreditCard, Wallet } from "lucide-react"

const transactions = [
  {
    id: "1",
    name: "Rahul Sharma",
    amount: 45000,
    status: "completed",
    type: "fee",
    date: "2023-04-15T09:24:45",
  },
  {
    id: "2",
    name: "Priya Patel",
    amount: 35000,
    status: "completed",
    type: "fee",
    date: "2023-04-14T14:10:32",
  },
  {
    id: "3",
    name: "Dr. Amit Kumar",
    amount: 85000,
    status: "completed",
    type: "salary",
    date: "2023-04-13T11:45:00",
  },
  {
    id: "4",
    name: "Neha Singh",
    amount: 42000,
    status: "pending",
    type: "fee",
    date: "2023-04-12T16:32:12",
  },
  {
    id: "5",
    name: "Prof. Suresh Joshi",
    amount: 78000,
    status: "completed",
    type: "salary",
    date: "2023-04-10T10:15:22",
  },
]

export function RecentTransactions() {
  return (
    <div className="space-y-8">
      {transactions.map((transaction) => (
        <div key={transaction.id} className="flex items-center">
          <Avatar className="h-9 w-9 mr-4">
            <AvatarFallback className={transaction.type === "fee" ? "bg-primary/10" : "bg-destructive/10"}>
              {transaction.type === "fee" ? (
                <CreditCard className="h-4 w-4 text-primary" />
              ) : (
                <Wallet className="h-4 w-4 text-destructive" />
              )}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1 space-y-1">
            <p className="text-sm font-medium leading-none">{transaction.name}</p>
            <p className="text-xs text-muted-foreground">
              {new Date(transaction.date).toLocaleDateString("en-IN", {
                day: "numeric",
                month: "short",
                year: "numeric",
              })}
            </p>
          </div>
          <div className="flex flex-col items-end gap-1">
            <div className="flex items-center">
              {transaction.type === "fee" ? (
                <ArrowDownLeft className="mr-1 h-4 w-4 text-emerald-500" />
              ) : (
                <ArrowUpRight className="mr-1 h-4 w-4 text-rose-500" />
              )}
              <span
                className={`text-sm font-medium ${transaction.type === "fee" ? "text-emerald-500" : "text-rose-500"}`}
              >
                ₹{transaction.amount.toLocaleString("en-IN")}
              </span>
            </div>
            <Badge variant={transaction.status === "completed" ? "outline" : "secondary"} className="text-xs">
              {transaction.status}
            </Badge>
          </div>
        </div>
      ))}
    </div>
  )
}
