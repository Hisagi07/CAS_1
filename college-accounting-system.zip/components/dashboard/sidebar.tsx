"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { useAuth } from "@/components/auth-provider"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { cn } from "@/lib/utils"
import {
  BookOpen,
  CreditCard,
  FileText,
  GraduationCap,
  HelpCircle,
  Home,
  LayoutDashboard,
  LogOut,
  Menu,
  MessageSquare,
  Users,
  Wallet,
} from "lucide-react"

interface SidebarProps {
  className?: string
}

export function Sidebar({ className }: SidebarProps) {
  const { user, logout } = useAuth()
  const pathname = usePathname()
  const [open, setOpen] = useState(false)

  const isAdmin = user?.role === "admin"

  const routes = isAdmin
    ? [
        {
          label: "Dashboard",
          icon: LayoutDashboard,
          href: "/admin/dashboard",
          active: pathname === "/admin/dashboard",
        },
        {
          label: "Students",
          icon: GraduationCap,
          href: "/admin/students",
          active: pathname === "/admin/students",
        },
        {
          label: "Staff",
          icon: Users,
          href: "/admin/staff",
          active: pathname === "/admin/staff",
        },
        {
          label: "Fee Management",
          icon: CreditCard,
          href: "/admin/fees",
          active: pathname === "/admin/fees",
        },
        {
          label: "Salary Management",
          icon: Wallet,
          href: "/admin/salaries",
          active: pathname === "/admin/salaries",
        },
        {
          label: "Reports",
          icon: FileText,
          href: "/admin/reports",
          active: pathname === "/admin/reports",
        },
        {
          label: "Help Desk",
          icon: HelpCircle,
          href: "/admin/help-desk",
          active: pathname === "/admin/help-desk",
        },
      ]
    : [
        {
          label: "Dashboard",
          icon: Home,
          href: "/student/dashboard",
          active: pathname === "/student/dashboard",
        },
        {
          label: "Fee Structure",
          icon: CreditCard,
          href: "/student/fees",
          active: pathname === "/student/fees",
        },
        {
          label: "Payments",
          icon: Wallet,
          href: "/student/payments",
          active: pathname === "/student/payments",
        },
        {
          label: "Documents",
          icon: FileText,
          href: "/student/documents",
          active: pathname === "/student/documents",
        },
        {
          label: "Help Desk",
          icon: HelpCircle,
          href: "/student/help-desk",
          active: pathname === "/student/help-desk",
        },
        {
          label: "Chat Assistant",
          icon: MessageSquare,
          href: "/student/chat",
          active: pathname === "/student/chat",
        },
      ]

  return (
    <>
      <Sheet open={open} onOpenChange={setOpen}>
        <SheetTrigger asChild className="lg:hidden">
          <Button variant="outline" size="icon" className="ml-2">
            <Menu className="h-5 w-5" />
            <span className="sr-only">Toggle Menu</span>
          </Button>
        </SheetTrigger>
        <SheetContent side="left" className="p-0">
          <MobileSidebar routes={routes} logout={logout} setOpen={setOpen} />
        </SheetContent>
      </Sheet>

      <div className={cn("hidden lg:flex h-screen border-r flex-col", className)}>
        <div className="p-6">
          <Link href="/" className="flex items-center gap-2 font-semibold">
            <BookOpen className="h-6 w-6" />
            <span className="font-bold">VISHWANIKETAN&apos;S IMEET</span>
          </Link>
        </div>

        <ScrollArea className="flex-1 px-4">
          <div className="space-y-1 py-2">
            {routes.map((route) => (
              <Link
                key={route.href}
                href={route.href}
                className={cn(
                  "flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium hover:bg-accent hover:text-accent-foreground",
                  route.active ? "bg-accent text-accent-foreground" : "transparent",
                )}
              >
                <route.icon className="h-5 w-5" />
                {route.label}
              </Link>
            ))}
          </div>
        </ScrollArea>

        <div className="mt-auto p-4 border-t">
          <Button variant="ghost" className="w-full justify-start gap-3" onClick={() => logout()}>
            <LogOut className="h-5 w-5" />
            Logout
          </Button>
        </div>
      </div>
    </>
  )
}

interface MobileSidebarProps {
  routes: {
    label: string
    icon: React.ElementType
    href: string
    active: boolean
  }[]
  logout: () => void
  setOpen: (open: boolean) => void
}

function MobileSidebar({ routes, logout, setOpen }: MobileSidebarProps) {
  return (
    <div className="flex h-full flex-col">
      <div className="p-6 border-b">
        <Link href="/" className="flex items-center gap-2 font-semibold" onClick={() => setOpen(false)}>
          <BookOpen className="h-6 w-6" />
          <span className="font-bold">VISHWANIKETAN&apos;S IMEET</span>
        </Link>
      </div>

      <ScrollArea className="flex-1">
        <div className="space-y-1 p-4">
          {routes.map((route) => (
            <Link
              key={route.href}
              href={route.href}
              onClick={() => setOpen(false)}
              className={cn(
                "flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium hover:bg-accent hover:text-accent-foreground",
                route.active ? "bg-accent text-accent-foreground" : "transparent",
              )}
            >
              <route.icon className="h-5 w-5" />
              {route.label}
            </Link>
          ))}
        </div>
      </ScrollArea>

      <div className="mt-auto p-4 border-t">
        <Button
          variant="ghost"
          className="w-full justify-start gap-3"
          onClick={() => {
            logout()
            setOpen(false)
          }}
        >
          <LogOut className="h-5 w-5" />
          Logout
        </Button>
      </div>
    </div>
  )
}
