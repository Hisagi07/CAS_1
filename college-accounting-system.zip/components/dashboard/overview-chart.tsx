"use client"

import { Bar, BarChart, CartesianGrid, Legend, ResponsiveContainer, Tooltip, XAxis, YAxis } from "@/components/ui/chart"

const data = [
  {
    name: "Jan",
    revenue: 2500000,
    expenses: 1800000,
  },
  {
    name: "Feb",
    revenue: 3200000,
    expenses: 2100000,
  },
  {
    name: "Mar",
    revenue: 4100000,
    expenses: 2400000,
  },
  {
    name: "Apr",
    revenue: 3800000,
    expenses: 2200000,
  },
  {
    name: "May",
    revenue: 4300000,
    expenses: 2500000,
  },
  {
    name: "Jun",
    revenue: 5100000,
    expenses: 2800000,
  },
  {
    name: "Jul",
    revenue: 4800000,
    expenses: 2600000,
  },
  {
    name: "Aug",
    revenue: 5500000,
    expenses: 3000000,
  },
  {
    name: "Sep",
    revenue: 6200000,
    expenses: 3200000,
  },
  {
    name: "Oct",
    revenue: 5800000,
    expenses: 3100000,
  },
  {
    name: "Nov",
    revenue: 6500000,
    expenses: 3400000,
  },
  {
    name: "Dec",
    revenue: 7200000,
    expenses: 3800000,
  },
]

// Format number to Indian Rupee format
const formatIndianRupee = (value: number) => {
  return `₹${(value / 100000).toFixed(1)}L`
}

export function Overview() {
  return (
    <ResponsiveContainer width="100%" height={350}>
      <BarChart data={data}>
        <CartesianGrid strokeDasharray="3 3" vertical={false} />
        <XAxis dataKey="name" stroke="#888888" fontSize={12} tickLine={false} axisLine={false} />
        <YAxis stroke="#888888" fontSize={12} tickLine={false} axisLine={false} tickFormatter={formatIndianRupee} />
        <Tooltip
          formatter={(value: number) => [`₹${(value).toLocaleString("en-IN")}`, ""]}
          labelFormatter={(label) => `Month: ${label}`}
        />
        <Legend />
        <Bar dataKey="revenue" name="Revenue" fill="#4f46e5" radius={[4, 4, 0, 0]} />
        <Bar dataKey="expenses" name="Expenses" fill="#f43f5e" radius={[4, 4, 0, 0]} />
      </BarChart>
    </ResponsiveContainer>
  )
}
